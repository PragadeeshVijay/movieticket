import pickle
import cv2
import mediapipe as mp
import numpy as np

# Load the pre-trained model from the pickle file
model_dict = pickle.load(open('./model.p', 'rb'))
model = model_dict['model']

# Open a connection to the default camera (0) using OpenCV
cap = cv2.VideoCapture(0)

# Initialize mediapipe hands module for hand tracking
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

# Configure the hands module with specific parameters
hands = mp_hands.Hands(static_image_mode=True, min_detection_confidence=0.3, max_num_hands=2)

# Define a dictionary to map numeric labels to corresponding hand gestures
labels_dict = labels_dict = {0: 'hello', 1: 'hello', 2: 'hello', 3: 'what',4:'what',5:'what',6:'how',7:'how',8:'how',9:'you',10:'you',11:'you',12:'time',13:'time',14:'time',15:'iloveyou',16:'iloveyou',17:'iloveyou',18:'hate',19:'hate',20:'hate',21:'name',22:'name',23:'name',24:'who',25:'who',26:'who',27:'food',28:'food',29:'food',30:'water',31:'water',32:'water',33:'thankyou',34:'thankyou',35:'thankyou',36:'happy',37:'happy',38:'happy',39:'think',40:'think',41:'think',42:'ok',43:'ok',44:'ok'}

# Start an infinite loop to capture video frames from the camera
while True:
    # Read a frame from the camera
    ret, frame = cap.read()

    # Check for errors in reading the frame
    if not ret or frame is None:
        print("Error: Couldn't read frame from the camera")
        break

    # Get the height (H), width (W), and channels (3 for RGB) of the frame
    H, W, _ = frame.shape

    # Convert the frame from BGR to RGB (required by mediapipe)
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Process the frame with the hands module to detect hand landmarks
    results = hands.process(frame_rgb)

    # Check if hand landmarks are detected
    if results.multi_hand_landmarks:
        # Extract hand landmarks and normalize them
        for hand_landmarks in results.multi_hand_landmarks:
            data_aux = []
            x_ = []
            y_ = []
            for i in range(len(hand_landmarks.landmark)):
                x = hand_landmarks.landmark[i].x
                y = hand_landmarks.landmark[i].y

                x_.append(x)
                y_.append(y)

            # Normalize hand landmarks
            for i in range(len(hand_landmarks.landmark)):
                x = hand_landmarks.landmark[i].x
                y = hand_landmarks.landmark[i].y
                data_aux.append(x - min(x_))
                data_aux.append(y - min(y_))

            # Ensure data_aux has exactly 42 features (adjust if necessary)
            data_aux_subset = data_aux[:42]

            # Make a prediction using the pre-trained model
            prediction = model.predict([np.asarray(data_aux_subset)])

            # Get the predicted character label
            predicted_character = labels_dict[int(prediction[0])]

            # Display the predicted word in the left top corner
            cv2.putText(frame, predicted_character, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2, cv2.LINE_AA)

    # Display the frame
    cv2.imshow('frame', frame)

    # Break the loop if the 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the camera and close all OpenCV windows
cap.release()
cv2.destroyAllWindows()
