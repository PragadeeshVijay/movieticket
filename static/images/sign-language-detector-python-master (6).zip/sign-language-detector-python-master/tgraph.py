import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Define the custom confusion matrix values
cm_values = np.array([[98, 2, 0, 0, 0, 0, 0, 0,0,0,0,0,0,0,0 ],
                      [1, 97, 2, 0, 0, 0, 0, 0,0,0,0,0,0,0,0],
                      [0, 0, 98, 0, 0, 0, 0, 0,0,0,0,2,0,0,0],
                      [0, 10, 0, 83, 0, 0, 0, 0,0,0,0,7,0,0,0],
                      [0, 0, 0, 3, 97, 0, 0, 0,0,0,0,0,0,0,0],
                      [0, 0, 0, 0, 0,  89, 0, 2,0,7,0,2,0,0,0],
                      [2, 0, 2, 0, 0, 0, 100, 0,0,0,0,0,0,0,0],
                      [0, 0, 0, 0, 0, 0, 0, 98,0,0,0,0,0,0,2],
                      [0, 0, 0, 0, 0, 0, 6, 0,73,0,18,0,0,3,0],
                      [0, 0, 0, 0, 0, 10, 0, 0,0,90,0,0,0,0,0],
                      [0, 0, 0, 0, 0, 0, 0, 0,3,0,97,0,0,0,0],
                      [0, 0, 0, 0, 0, 0, 0, 0,0,0,0,99,1,0,0],
                      [0, 1, 0, 0, 0, 0, 0, 0,0,0,0,2,97,0,0],
                      [0, 0, 0, 0, 0, 0, 0, 0,0,0,0,0,3,97,0],
                      [0, 0, 0, 0, 0, 0, 0, 0,0,0,0,0,0,2,98]])

# Calculate the training accuracy
train_accuracy = np.sum(np.diag(cm_values)) / np.sum(cm_values)

# Dummy accuracy values for multiple epochs
accuracy_values = [train_accuracy - 0.05, train_accuracy - 0.03, train_accuracy - 0.02, train_accuracy, 
                   train_accuracy + 0.01, train_accuracy + 0.02, train_accuracy + 0.03, train_accuracy + 0.04]

# Plot accuracy graph
plt.figure(figsize=(10, 6))
plt.plot(range(1, len(accuracy_values) + 1), accuracy_values, marker='o', color='b', label='Training Accuracy')
plt.title('Accuracy Graph Over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.xticks(range(1, len(accuracy_values) + 1))
plt.grid(True)
plt.legend()
plt.show()
