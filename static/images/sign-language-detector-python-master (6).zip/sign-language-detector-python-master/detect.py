import pickle
import cv2
import mediapipe as mp
import numpy as np
import pyttsx3

# Load the hand gesture recognition model
model_dict = pickle.load(open('./model.p', 'rb'))
model = model_dict['model']

username=input("Enter Your Name: ")

labels_dict = {0: 'hello',1:'goodbye',2:'stop',3:'Thankyou',4:'love',5:'i',6:'you',7:'okay',8:'water',9:'think',10:'why',11:'what',12:'how',13:'where',14:'when',15:'sleep',16:'name',17:username,18:'Bad',19:'happy',20:'good',21:'friend',22:'home',23:'need',24:'hate',25:'which',26:'big',27:'food',28:'morning',29:'speak',30:'Go',31:'Learn',32:'Read',33:'Touch',34:'Hear',35:'Feel',36:'Understand',37:'Forget',38:'Funny',39:'Small',40:'Strong',41:'Excited',42:'Beautiful',43:'Silence',44:'Wait',45:' Help',46:'Finish',47:'Angry',48:'Believe',49:'Dream',50:'See'}
# Initialize the video capture
cap = cv2.VideoCapture(0)

# Initialize MediaPipe Hands module
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

# Initialize MediaPipe Hands
hands = mp_hands.Hands(static_image_mode=True, min_detection_confidence=0.3, max_num_hands=2)



# Initialize text-to-speech engine with increased speed
engine = pyttsx3.init()
engine.setProperty('rate', 300)  # Adjust the value (words per minute) to increase or decrease the speed

# Function to convert labels to grammatical forms
def to_grammatical_form(word):
    # Add more rules as needed
    if word.lower() == 'i':
        return 'I'
    elif word.lower() == 'you':
        return 'you'
    elif word.lower() == 'how':
        return 'how'
    elif word.lower() == 'what':
        return 'what'
    elif word.lower() == 'where':
        return 'where'
    elif word.lower() == 'when':
        return 'when'
    elif word.lower() == 'our name':
        return 'our name'
    else:
        return word

# Function to process the stored sentence
def process_stored_sentence(sentence):
    # Add your custom sentence transformations here
    if sentence.lower().strip() == 'stop think you speak':
        return 'Stop, think before you speak'
    if sentence.lower().strip() == 'how you':
        return 'How are you'
    if sentence.lower().strip()=='i think you speak':
        return 'I Think You can Speak Now'
    if sentence.lower().strip() == 'you happy home':
        return 'Are you happy at home?'
    if sentence.lower().strip() == 'thank you food':
        return 'Thank you for the food.'
    if sentence.lower().strip() == 'why you hate mornings':
        return 'Why do you hate mornings?'
    if sentence.lower().strip() == 'water feel good':
        return 'Water makes me feel good.'
    if sentence.lower().strip() == 'how i help you':
        return 'How can I help you?'
    if sentence.lower().strip() == 'when you finish':
        return 'When will you finish?'
    if sentence.lower().strip() == 'what you name':
        return 'What is your Name?'
    if sentence.lower().strip() == 'you need water':
        return 'Do you need Water?'
    if sentence.lower().strip() == 'i need think':
        return 'I Need to think'
    if sentence.lower().strip() == 'i speak':
        return 'Shall I Speak'
    if sentence.lower().strip() == 'i need speak':
        return 'I Need to Speak'
    else:
        return sentence

# Initialize the stored sentence
stored_sentence = ""

while True:
    ret, frame = cap.read()

    if not ret or frame is None:
        print("Error: Couldn't read frame from the camera")
        break

    H, W, _ = frame.shape

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Process the frame to detect hands
    results = hands.process(frame_rgb)
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            # Draw landmarks and connections on the frame
            mp_drawing.draw_landmarks(
                frame,
                hand_landmarks,
                mp_hands.HAND_CONNECTIONS,
                mp_drawing_styles.get_default_hand_landmarks_style(),
                mp_drawing_styles.get_default_hand_connections_style())

        for hand_landmarks in results.multi_hand_landmarks:
            data_aux = []
            x_ = []
            y_ = []
            for i in range(len(hand_landmarks.landmark)):
                x = hand_landmarks.landmark[i].x
                y = hand_landmarks.landmark[i].y

                x_.append(x)
                y_.append(y)

            for i in range(len(hand_landmarks.landmark)):
                x = hand_landmarks.landmark[i].x
                y = hand_landmarks.landmark[i].y
                data_aux.append(x - min(x_))
                data_aux.append(y - min(y_))

            data_aux_subset = data_aux[:42]

            x1 = int(min(x_) * W) - 10
            y1 = int(min(y_) * H) - 10

            x2 = int(max(x_) * W) - 10
            y2 = int(max(y_) * H) - 10

            prediction = model.predict([np.asarray(data_aux_subset)])

            predicted_label = labels_dict.get(int(prediction[0]), '')  # Get the predicted label from the dictionary

            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 0), 4)
            cv2.putText(frame, predicted_label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 0, 0), 3,
                        cv2.LINE_AA)

    cv2.imshow('frame', frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break
    elif key == ord('s') and predicted_label:  # Store the predicted label
        stored_sentence += " " + predicted_label
        print(f"Stored sentence: {stored_sentence}")
    elif key == ord('k') and stored_sentence:  # Read out the stored sentence
        stored_sentence = process_stored_sentence(stored_sentence)
        print(f"Processed sentence: {stored_sentence}")
        words = stored_sentence.split()
        for word in words:
            engine.say(word)
            engine.runAndWait()
        stored_sentence = ""  # Reset the stored sentence

# Release resources
cap.release()
cv2.destroyAllWindows()

