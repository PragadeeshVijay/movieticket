import pickle
import cv2
import mediapipe as mp
import numpy as np
import pyttsx3
import time

model_dict = pickle.load(open('./model.p', 'rb'))
model = model_dict['model']

cap = cv2.VideoCapture(0)

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

hands = mp_hands.Hands(static_image_mode=True, min_detection_confidence=0.9, max_num_hands=2)

labels_dict = labels_dict = {0: 'hello', 1: 'hello', 2: 'hello', 3: 'what',4:'what',5:'what',6:'how',7:'how',8:'how',9:'you',10:'you',11:'you',12:'time',13:'time',14:'time',15:'iloveyou',16:'iloveyou',17:'iloveyou',18:'hate',19:'hate',20:'hate',21:'name',22:'name',23:'name',24:'who',25:'who',26:'who',27:'food',28:'food',29:'food',30:'water',31:'water',32:'water',33:'thankyou',34:'thankyou',35:'thankyou',36:'happy',37:'happy',38:'happy',39:'think',40:'think',41:'think',42:'ok',43:'ok',44:'ok'}

predicted_character = None
stored_character = ""

# Initialize text-to-speech engine
engine = pyttsx3.init()

# Variable to store the time of the last keyboard press
last_key_press_time = time.time()

while True:
    ret, frame = cap.read()

    if not ret or frame is None:
        print("Error: Couldn't read frame from the camera")
        break

    H, W, _ = frame.shape

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    results = hands.process(frame_rgb)
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_drawing.draw_landmarks(
                frame,
                hand_landmarks,
                mp_hands.HAND_CONNECTIONS,
                mp_drawing_styles.get_default_hand_landmarks_style(),
                mp_drawing_styles.get_default_hand_connections_style())

        for hand_landmarks in results.multi_hand_landmarks:
            data_aux = []
            x_ = []
            y_ = []
            for i in range(len(hand_landmarks.landmark)):
                x = hand_landmarks.landmark[i].x
                y = hand_landmarks.landmark[i].y

                x_.append(x)
                y_.append(y)

            for i in range(len(hand_landmarks.landmark)):
                x = hand_landmarks.landmark[i].x
                y = hand_landmarks.landmark[i].y
                data_aux.append(x - min(x_))
                data_aux.append(y - min(y_))

            data_aux_subset = data_aux[:42]

            x1 = int(min(x_) * W) - 10
            y1 = int(min(y_) * H) - 10

            x2 = int(max(x_) * W) - 10
            y2 = int(max(y_) * H) - 10

            prediction = model.predict([np.asarray(data_aux_subset)])

            predicted_character = labels_dict[int(prediction[0])]

            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 0), 4)
            cv2.putText(frame, predicted_character, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 0, 0), 3,
                        cv2.LINE_AA)

    cv2.imshow('frame', frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break
    elif key == ord('s') and predicted_character is not None:
        stored_character = stored_character + " " + predicted_character
        print(f"Stored character: {stored_character}")
        # Update the time of the last keyboard press
        last_key_press_time = time.time()
    elif time.time() - last_key_press_time >= 6 and stored_character:
        # If no keyboard press for 3 seconds, read the stored characters as audio
        words = stored_character.split()
        for word in words:
            engine.say(word)
            engine.runAndWait()
        stored_character=""

cap.release()
cv2.destroyAllWindows()
