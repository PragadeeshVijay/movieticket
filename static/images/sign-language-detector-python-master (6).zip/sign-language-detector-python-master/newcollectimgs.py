import os
import cv2

DATA_DIR = './data'
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

number_of_classes = 1
dataset_size = 0

cap = cv2.VideoCapture(0)  # Use 0 instead of 2 if you have only one camera

for j in range(1):
    if not os.path.exists(os.path.join(DATA_DIR, str(j + number_of_classes))):
        os.makedirs(os.path.join(DATA_DIR, str(j + number_of_classes)))

    print('Collecting data for class {}'.format(j + number_of_classes))

    done = False
    while True:
        ret, frame = cap.read()
        cv2.imshow('frame', frame)
        key = cv2.waitKey(1)
        if key == ord('s'):
            cv2.imwrite(os.path.join(DATA_DIR, str(j + number_of_classes), '{}.jpg'.format(dataset_size)), frame)
            dataset_size += 1
            print("Image {} captured for class {}".format(dataset_size, j + number_of_classes))
        elif key == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()
